<div class="alert <?php echo $class?> alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span class="disclbtn" 	aria-hidden="true">&times;</span>
    </button>
    <?php echo $message?>
</div>

<!--<div class="alert <?php /*echo $class*/?> alert-dismissible fade show" role="alert">
    <?php /*echo $message*/?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>-->