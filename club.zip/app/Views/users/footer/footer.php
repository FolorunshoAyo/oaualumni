
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Wrapper End -->
<script type="text/javascript">
        baseurl="<?php echo base_url()?>"
        sturl="<?php echo site_url()?>"
</script>
<!-- Javascript Files -->
<script src="<?php echo site_url('public/assets/club/js/jquery.min.js')?>"></script>
<!--jQuery Layer Slider -->
<script src="<?php echo site_url('public/assets/club/js/greensock.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/layerslider.transitions.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/layerslider.kreaturamedia.jquery.js')?>"></script>
<!--jQuery Layer Slider -->
<script src="<?php echo site_url('public/assets/club/js/popper.min.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/bootstrap.min.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/owl.carousel.min.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/tmpl.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/jquery.dependClass-0.1.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/draggable-0.1.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/jquery.slider.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/chart.min.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/wow.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/YouTubePopUp.jquery.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/validate.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/jquery.cookie.js')?>"></script>
<script src="<?php echo site_url('public/assets/club/js/custom.js')?>"></script>