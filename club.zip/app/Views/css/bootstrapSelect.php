
<link rel="stylesheet" href="<?php echo base_url('public/assets/css/select2.min.css'); ?>" type="text/css" charset="utf-8" />
