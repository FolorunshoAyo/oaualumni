<?php namespace Config;

class Validation
{
	//--------------------------------------------------------------------
	// Setup
	//--------------------------------------------------------------------

	/**
	 * Stores the classes that contain the
	 * rules that are available.
	 *
	 * @var array
	 */
	public $ruleSets = [
		\CodeIgniter\Validation\Rules::class,
		\CodeIgniter\Validation\FormatRules::class,
		\CodeIgniter\Validation\FileRules::class,
		\CodeIgniter\Validation\CreditCardRules::class,
	];

	/**
	 * Specifies the views that are used to display the
	 * errors.
	 *
	 * @var array
	 */
    /*club script starts here*/
    public $login = [
        'email'=> 'trim|required',
        'password'=> 'trim|required',
    ];
    public $register = [
        'first_name'=> 'trim|required|alpha_space',
        'last_name'=> 'trim|required|alpha_space',
        'conf_password'=> 'trim|required|matches[password]',
        'occupation'=> 'trim|required',
        'address'=> 'trim|required',
        'hobbies'=> 'trim|required',
        'email'=> 'trim|required|valid_email',
        'password'=> 'trim|required',

        /*'accept'=> 'trim|required',*/
        /*'agreeTermCon'=> 'required'*/
    ];
    public $userQuery = [
        'name'=> 'trim|required',
        'email'=> 'trim|required|valid_email',
        'relPhone'=> 'trim|required',
        'subject'=> 'trim|required',
         'message'=> 'trim|required',
        /*'agreeTermCon'=> 'required'*/
    ];
    public $profile = [
        'first_name'=> 'trim|required|alpha_space',
        'last_name'=> 'trim|required|alpha_space',
        'occupation'=> 'trim|required',
        'address'=> 'trim|required',
        'hobbies'=> 'trim|required'

        /*'agreeTermCon'=> 'required'*/
    ];
    public $userUpdateAdmin = [
        'first_name'=> 'trim|required|alpha_space',
        'last_name'=> 'trim|required|alpha_space',
        'occupation'=> 'trim|required',
        'address'=> 'trim|required',
        'hobbies'=> 'trim|required'
    ];
    public $newsEvent = [
        'title'=> 'required',
        'description'=> 'required',
        'category'=> 'required'
    ];

    /*club script ends here*/
	public $templates = [
		'list'   => 'CodeIgniter\Validation\Views\list',
		'single' => 'CodeIgniter\Validation\Views\single',
	];


    public $register_errors = [
        'User Name' => [
            'required'    => 'User name is required.',
        ],
        'email'    => [
            'required' => 'Email is required'
        ],
        'password'    => [
            'required' => 'Password is required'
        ],
        'Confirm Password'    => [
            'required' => 'Your password and confirm password must be the same.'
        ],
        'Phone'    => [
            'required' => 'Phone number is required.'
        ],
        'accept'    => [
            'required' => 'You have to accept our terms and condition.'
        ]
    ];




    public $adminLogin = [
        'username'=> 'trim|required',
        'password'=> 'trim|required',
    ];


    public $newAdmin = [
        'name'=> 'trim|required',
        'email'=> 'trim|required|valid_email',
        'password'=> 'trim|required',
        'status'=> 'trim|required|integer'

    ];




	//--------------------------------------------------------------------
	// Rules
	//--------------------------------------------------------------------
}
