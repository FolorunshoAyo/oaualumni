<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/register', 'User::register');
//$routes->get('/new-user/', 'User::newUser');
$routes->get('/update-pofile', 'User::updateUser');
$routes->get('/login', 'User::login');
$routes->get('/contact', 'Pages::contact');
$routes->post('contact/send-message', 'Pages::userQuery');
$routes->get('/faq', 'Pages::faq');

$routes->get('admin/new-news-and-event', 'Admin::newNewsEvents');
$routes->post('admin/add-news-and-event', 'Admin::addNewsEvents');
$routes->get('admin/all-news-and-events', 'Admin::allNewsEvents');
$routes->get('admin/edit-news-and-events/(:segment)', 'Admin::editNewsEvents/$1');
$routes->post('admin/update-news-and-event', 'Admin::updateNewsEvents');


$routes->get('/news', 'NewsEvents::index');
$routes->get('news/readnrews/(:segment)', 'NewsEvents::readnrews/$1');
$routes->get('events/read/(:segment)', 'NewsEvents::readView/$1');
//$route['events/read/(:num)'] = 'newsEvents/readView/$1';
$routes->get('/events', 'NewsEvents::events');
$routes->get('events/read/(:segment)', 'NewsEvents::read/$1');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
