<?php


namespace App\Controllers;


use App\Models\ModAdmin;
use App\Models\ModContact;
use App\Models\ModUsers;
use App\Models\ModNewEvents;
use CodeIgniter\Database\MySQLi\Utils;
use CodeIgniter\I18n\Time;
use CodeIgniter\Model;
use Config\Services;

class Admin extends BaseController
{

    function __construct()
    {
        $this->validator = \Config\Services::validation();
        $this->request = \Config\Services::request();
        $this->session = \Config\Services::session();
    }
    protected $helpers = ['url', 'custom_helper','form','text'];
    /*club code starts here*/
    public function users()
    {
        if (isAdmin()){
            $request = $this->request;
            $filters = $this->filterWhereForModels();//filtering for models
            $tableUsers = new ModUsers();

            $pageRange = $request->getGet('ppg');
            if (isset($pageRange) && !empty($pageRange)) {
                $perPage = $pageRange;
            }
            else{
                $perPage = 20;
            }
            $filters['u_status']=1;
            $tableUsers->where($filters)->orderBy('u_id','desc');
            $data = [
                'skzUsers' => $tableUsers->paginate($perPage),
                'pager' => $tableUsers->pager,
                'filters' => $this->filterWhereForview()
            ];

            $data['AllUsers'] = $tableUsers->where(['u_status'=>1])->findAll();
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/css/datePicker');
            echo view('css/bootstrapSelect');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/users',$data);
            echo view('admin/footer/footer');
            echo view('admin/js/datePicker');
            echo view('js/bootstrapSelect');
            echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }
    public function logIn(){

        if (!isAdmin()){
            $data['title'] =  'Admin Login' .PROJECT;
            echo view('admin/content/login');
        }
        else{
            return redirect()->to(site_url('admin'));
        }
    }
    public function logout(){
        if (isAdmin()){
            $session =  $this->session;
            $session->destroy();
            // redirect('admin/login');
            return redirect()->to(base_url());
        }
        else{
            return redirect()->to(site_url('admin/login'));
        }
    }
    public function checkUser()
    {
        //die();
        $validation = $this->validator;
        $request = $this->request;
        $session =  $this->session;
        $tableAdmin =  new ModAdmin();
        $data['email'] = $request->getPost('username'); //$this->input->post('username');
        $data['password'] = $request->getPost('password'); //$this->input->post('password');
        //var_dump($data);
        //die();
        if (!$this->validate($validation->getRuleGroup('adminLogin'))){
            customFlash('alert-warning','Please check required fields and try again.');
            return redirect()->to(site_url('admin/login'));
        }
        else{
            $data['password'] = hash('md5',$data['password']);
            $checkAdmin = $tableAdmin->checkAdmin($data);
            if ($checkAdmin){
                //var_dump($data);
                $sessionAdmin['aId'] = $checkAdmin[0]['aId'];
                $sessionAdmin['aName'] = $checkAdmin[0]['aName'];
                $sessionAdmin['aDate'] = $checkAdmin[0]['aDate'];
                $sessionAdmin['email'] = $checkAdmin[0]['email'];
                $sessionAdmin['aDp'] = $checkAdmin[0]['aDp'];
                $sessionAdmin['aSuperAdmin'] = $checkAdmin[0]['aSuperAdmin'];
                $session->set($sessionAdmin);
                if (isAdmin()){
                    //redirect('admin');
                    return redirect()->to(site_url('admin'));

                }
                else{
                    customFlash('alert-warning','You can not login right now please try again.');
                    return redirect()->to(site_url('admin/login'));

                }
            }
            else{
                customFlash('alert-warning','UserName or Password Invalid.');
                return redirect()->to(site_url('admin/login'));

            }
        }
    }


    public function editUser($id)
    {
        if (isAdmin() && isSuperAdmin()){
            if (!empty($id) && isset($id)) {
                $tableUsers = new ModUsers();
                $data['userData'] = $tableUsers->getUserInfo($id);
                // $data['userInfo'] = $this->modAdmin->getUserInfo($id);
                if (count($data['userData']) === 1) {
                    $data['title'] =  'Edit User | ' .PROJECT;
                    echo view('admin/header/header',$data);
                    echo view('admin/css/css');
                    echo view('css/phone');
                    echo view('admin/navbar/navbartop');
                    echo view('admin/navbar/navbar_left');
                    echo view('admin/content/editUser',$data);
                    echo view('admin/footer/footer');
                    echo view('js/phone');
                    echo view('admin/endfooter/endfooter');

                }
                else{
                    customFlash('alert-warning','The User is not available please try again.');
                    return redirect()->to(site_url('admin/users'));
                }
            }
            else{
                customFlash('alert-warning','Something went wrong.');
                return redirect()->to(site_url('admin/users'));
            }
        }
        else{
            customFlash('alert-warning','Please login first.','admin/login');
            return redirect()->to(site_url('admin/login'));
        }

    }

    public function updateUser()
    {
        if (isAdmin()) {
            $validation = $this->validator;
            $request = $this->request;
            $tableUsers = new ModUsers();

            if (!$this->validate($validation->getRuleGroup('userUpdateAdmin'))) {
                customFlash('alert-info','Please check your required fields and try again.');
                return redirect()->back();
            }
            else{
                $userId = $request->getPost('xyp');
                if (isset($userId) && !empty($userId)) {
                    $checkUser = $tableUsers->where('u_id',$userId)->findAll();
                    if (count($checkUser) == 1) {
                        $data['u_first_name'] = $request->getPost('first_name');
                        $data['u_last_name'] = $request->getPost('last_name');
                        $data['u_occupation'] = $request->getPost('occupation');
                        $data['u_address'] = $request->getPost('address');
                        $data['u_hobbies'] = $request->getPost('hobbies');
                        $password = $request->getPost('password');
                        $old_pic = $request->getPost('xceep');

                        if (isset($password) && !empty($password)) {
                            $data['password'] = hash('md5',$password);
                        }
                        $profilePic = $this->request->getFile('dp');
                        if (!empty($profilePic) && $profilePic->getSize() > 0) {
                            $profileFileName = $profilePic->getRandomName();
                            $profilePic->move('./public/assets/images/users',$profileFileName);
                            $data['u_dp'] = $profileFileName;
                        }//checking image if selected.
                        $updateUserSKZ = $tableUsers->update($userId,$data);
                        if ($updateUserSKZ){
                            if (!empty($old_pic)){
                                if (file_exists('./public/assets/images/users/'.$old_pic))
                                {
                                    unlink('./public/assets/images/users/'.$old_pic);
                                }
                            }
                            customFlash('alert-success','Your profile is updated');
                            return redirect()->to(site_url('admin/users'));
                        }
                        else{
                            customFlash('alert-info','You can\'t update your profile right now please contact admin');
                            return redirect()->to(site_url('admin/users'));
                        }
                    }
                    else{
                        customFlash('alert-success','The user id not exist. ');
                        return redirect()->to(site_url('admin/users'));
                    }

                }
                else{
                    customFlash('alert-success','The user id is required; please check it and try again later.');
                    return redirect()->to(site_url('admin/users'));
                }
            }
        }
        else{
            customFlash('alert-warning','Login now before accessing dashboard.');
            return redirect()->to(site_url('admin/login'));
        }
    }
    public function pendingusers()
    {
        if (isAdmin()){
            $request = $this->request;
            $filters = $this->filterWhereForModels();//filtering for models
            $tableUsers = new ModUsers();

            $pageRange = $request->getGet('ppg');
            if (isset($pageRange) && !empty($pageRange)) {
                $perPage = $pageRange;
            }
            else{
                $perPage = 20;
            }
            $filters['u_status'] = 0;
            $tableUsers->where($filters)->orderBy('u_id','desc');
            $data = [
                'skzUsers' => $tableUsers->paginate($perPage),
                'pager' => $tableUsers->pager,
                'filters' => $this->filterWhereForview()
            ];

            $data['AllUsers'] = $tableUsers->where(['u_status'=>1])->findAll();
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/css/datePicker');
            echo view('css/bootstrapSelect');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/pendingusers',$data);
            echo view('admin/footer/footer');
            echo view('admin/js/datePicker');
            echo view('js/bootstrapSelect');
            echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }


    public function ApproveUser($userId,$Status)
    {
        if (isAdmin()){
            $tableUsers = new ModUsers();
            if (!empty($userId) && isset($userId) && isset($Status) && !empty($Status)) {
                $isUserExist = $tableUsers->where(['u_id'=>$userId])->findAll();
                if (count($isUserExist) === 1) {
                    switch ($Status) {
                        case 2:
                            $userData['u_status'] = 0;
                            $myError = 'You have disabled the user';
                            break;
                        case 1:
                            $userData['u_status'] = 1;
                            $myError = 'You have successfully Approved';
                            break;
                        default:
                            $myError = 'Something went wrong; please try again.';
                            break;
                    }
                    //var_dump($userData);
                    //die();
                    $machinStaus = $tableUsers->update($userId,$userData);
                    if ($machinStaus) {
                        customFlash('alert-success',$myError);
                        return redirect()->to(site_url('admin/users'));
                    }
                    else{
                        customFlash('alert-info','You can\'t change the status right now.');
                        return redirect()->to(site_url('admin/users'));
                    }

                }
                else{
                    customFlash('alert-warning','The user is not available; please try again.');
                    return redirect()->to(site_url('admin/users'));
                }
            }
            else{
                customFlash('alert-warning','Something went wrong; please get in touch with the developer.');
                return redirect()->to(site_url('admin/users'));
            }
        }
        else{
            customFlash('alert-warning','Please log in first.');
            return redirect()->to(site_url('admin/login'));
        }

    }
    public function queries()
    {
        if (isAdmin()){
            $tableContact = new ModContact();
            $tableContact->orderBy('con_id','desc');
            $tableContact->join('users','users.u_id = contact.user_id','left');
            $data = [
                'allMessages' => $tableContact->paginate(20),
                'pager' => $tableContact->pager,
            ];

            $data['title'] =  'All Messages | ' .PROJECT;
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/allMessage',$data);
            echo view('admin/footer/footer');
            //echo view('admin/footer/homeJs');
            echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }
    public function index()
    {
        if (isAdmin()){
            $data['title'] =  'Admin' . PROJECT;
            $tableUsers =  new ModUsers();

            $data['users'] = $tableUsers->getAllUsers(1);
            $data['pendingUsers'] = $tableUsers->getAllUsers(0);
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/homenew',$data);
            echo view('admin/footer/footer');
            echo view('admin/footer/homeJs');
            echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-warning','Please login with your account.','');
            return redirect()->to(site_url('admin/login'));
        }
    }
    /*newsEvents starts here*/
    public function newNewsEvents()
    {
        if (isAdmin()){

            $data['title'] =  'New News / Event | ' .PROJECT;
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/css/quill');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/newNewsEvents',$data);
            echo view('admin/footer/footer');
            echo view('admin/css/quilljs');
            echo view('admin/endfooter/endfooter');

        }
        else{
            customFlash('alert-info','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }
    }

    public function addNewsEvents()
    {
        if (isAdmin()){

            $tableNewEvents =  new ModNewEvents();
            $validation = $this->validator;
            $request = $this->request;
            $session =  $this->session;
            if (!$this->validate($validation->getRuleGroup('newsEvent')))
            {
                $this->newNewsEvents();
            }
            else
            {
                $newNewsEvent = [
                    'ne_title'=>$request->getPost('title'),
                    'ne_description'=> base64_encode($request->getPost('description')),
                    'ne_category'=>$request->getPost('category'),
                    'admin_id'=> getAdminId()
                ];

                $messageImage = $request->getFile('image');
                if (!empty($messageImage) && $messageImage->getSize() > 0)
                {
                    $newNewsEvent['ne_dp'] = $messageImage->getRandomName();
                    $messageImage->move('./public/assets/images/newsEvents',$newNewsEvent['ne_dp']);
                }
                else
                {
                    customFlash('alert-danger','Please select your image and try again.');
                    return redirect()->to(site_url('admin/new-news-and-event'));
                }
                //dd($newNewsEvent);
                $checkNewsEvent = $tableNewEvents->
                where(['ne_title'=>$newNewsEvent['ne_title']])
                    ->findAll();
                if (count($checkNewsEvent) > 0) {
                    customFlash('alert-success',$newNewsEvent['ne_title'].'already exist.');
                    return redirect()->to(site_url('admin/new-news-and-event'));

                }
                else{
                    $NewsEvents = $tableNewEvents->insert($newNewsEvent);
                    if ($NewsEvents) {
                        customFlash('alert-success','You have successfully inserted');
                        return redirect()->to(site_url('admin/new-news-and-event'));

                    }
                    else{
                        customFlash('alert-info','OOps..! something went wrong please try again.');
                        return redirect()->to(site_url('admin/new-news-and-event'));
                    }
                }

            }
        }
        else{
            customFlash('alert-info','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }
    }
    public function allNewsEvents()
    {
        if (isAdmin()){
            $request = $this->request;
            $tableNewEvents =  new ModNewEvents();
            $tableUsers = new ModUsers();
            $filters = $this->filterWhereForModels();//filtering for models
            $pageRange = $request->getGet('ppg');
            if (isset($pageRange) && !empty($pageRange)) {
                $perPage = $pageRange;
            }
            else{
                $perPage = 20;
            }
            //dd($filters);
            $filters['ne_status'] = 1;
            $tableNewEvents
                ->where($filters);
            $data = [
                'allEvents' => $tableNewEvents->paginate($perPage),
                'pager' => $tableNewEvents->pager,
                'filters' => $this->filterWhereForview()
            ];
            /*lastQuery();
            dd();*/
            $data['AllUsers'] = $tableUsers->where(['u_status'=>1])->findAll();
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/css/datePicker');
            echo view('css/bootstrapSelect');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/allNewsEvents',$data);
            echo view('admin/footer/footer');
            echo view('admin/js/datePicker');
            echo view('js/bootstrapSelect');
            echo view('admin/endfooter/endfooter');

        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }
    public function editNewsEvents($id)
    {
        if (isAdmin()){
            if (!empty($id) && isset($id)) {
                $tableNewsEvent = new ModNewEvents();
                $isEvents = $tableNewsEvent->where('ne_id',$id)->findAll();
                if (count($isEvents) === 1) {
                    $data['events'] = $isEvents  ;
                    $data['title'] =  'Admin - Login | Shakzee';
                    echo view('admin/header/header');
                    echo view('admin/css/css');
                    echo view('admin/css/quill');
                    echo view('admin/navbar/navbartop');
                    echo view('admin/navbar/navbar_left');
                    echo view('admin/content/editNewsEvents',$data);
                    echo view('admin/footer/footer');
                    echo view('admin/css/quilljs');
                    echo view('admin/endfooter/endfooter');
                }
                else{
                    customFlash('alert-danger','The News/event is not available please try again.');
                    return redirect()->to(site_url('admin/edit-news-and-events/'.$id));
                }
            }
            else{
                customFlash('alert-danger','Some thing went wrong.');
                return redirect()->to(site_url('admin/all-news-and-events'));
            }
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }

    public function updateNewsEvents()
    {
        if (isAdmin()){
            $tableNewEvents =  new ModNewEvents();
            $validation = $this->validator;
            $request = $this->request;
            $session =  $this->session;
            $addStatus = $validation->getRuleGroup('newsEvent');
            $addStatus['status'] = 'required|integer';
            if (!$this->validate($addStatus))
            {
                customFlash('alert-info','Please check the required fields and try again');
                return redirect()->to(site_url('admin/all-news-and-events'));
            }
            else
            {

                $oldImage = $request->getPost('dimgo');
                $eventId = $request->getPost('xeew');

                $editNewEvent = [
                    'ne_title'=>$request->getPost('title'),
                    'ne_description'=>base64_encode($request->getPost('description')),
                    'ne_category'=>$request->getPost('category'),
                    'ne_status'=>$request->getPost('status'),
                    'admin_id'=>getAdminId(),
                ];

                if (!empty($eventId) && isset($eventId)) {
                    $checkNewsEvent = $tableNewEvents->where([
                        'ne_title'=>$editNewEvent['ne_title'],
                        'ne_id !='=>$eventId
                    ])->findAll();
                    //dd();
                    if (count($checkNewsEvent) > 0) {
                        customFlash('alert-info','New/Event already exist.');
                        return redirect()->to(site_url('admin/edit-news-and-events/'.$editNewEvent));
                    }
                    else{
                        //dd();
                        $NewEventImage = $request->getFile('image');
                        if (!empty($NewEventImage) && $NewEventImage->getSize() > 0)
                        {

                            $editNewEvent['ne_dp'] = $NewEventImage->getRandomName();
                            $NewEventImage->move('./public/assets/images/newsEvents',$editNewEvent['ne_dp']);
                        }//checking image if selected.


                        $isUpdated = $tableNewEvents->update($eventId,$editNewEvent);
                        if ($isUpdated) {
                            if (isset($editNewEvent['ne_dp']) && !empty($editNewEvent['ne_dp'])) {
                                $imagePath = realpath(APPPATH . '../public/assets/images/newsEvents/');
                                if (file_exists($imagePath.'/'.$oldImage))
                                {
                                    unlink($imagePath.'/'.$oldImage);
                                }
                            }
                            customFlash('alert-success','You have successfully updated');
                            return redirect()->to(site_url('admin/all-news-and-events'));
                        }
                        else{
                            customFlash('alert-success','OOps..! something went wrong please try again.');
                            return redirect()->to(site_url('admin/all-news-and-events'));
                        }
                    }

                }
                else{
                    customFlash('alert-info','Something went wrong please try again');
                    return redirect()->to(site_url('admin/all-news-and-events'));

                }

            }
        }
        else{
            customFlash('alert-info','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }
    }

    private function filterWhereForview()
    {
        $request = $this->request;
        $user = $request->getGet('user');
        $fup = $request->getGet('fup');
        $tup = $request->getGet('tup');
        $query = $request->getGet('q');
        $page = $request->getGet('ppg');

        $fnev = $request->getGet('fnev');
        $tnev = $request->getGet('tnev');


        $filters = false;
        if (isset($user) && !empty($user))
        {
            $filters['user'] = $user ;
        }
        else{
            $filters['user'] = '' ;
        }
        if (isset($page) && !empty($page))
        {
            $filters['page'] = $page ;
        }
        else{
            $filters['page'] = '' ;
        }
        if (isset($fud) && !empty($fud))
        {
            $filters['fud'] = $fud ;
        }
        else{
            $filters['fud'] = '' ;
        }
        if (isset($tud) && !empty($tud))
        {
            $filters['tud'] = $tud;
        }
        else{
            $filters['tud'] = '' ;
        }

        if (isset($fnev) && !empty($fnev))
        {
            $filters['fnev'] = $fnev ;
        }
        else{
            $filters['fnev'] = '' ;
        }
        if (isset($tnev) && !empty($tnev))
        {
            $filters['tnev'] = $tnev;
        }
        else{
            $filters['tnev'] = '' ;
        }

        return $filters;
    }
    private function filterWhereForModels()
    {
        $filters = array();
        $request = $this->request;
        if (!empty($_GET)) {
            $filters = false;
            $user = $request->getGet('user');//$this->input->get('user',TRUE);
            $fud = $request->getGet('fud');//$this->input->get('fud',TRUE);
            $tud = $request->getGet('tud');//$this->input->get('tud',TRUE);

            $fnevx = $request->getGet('fnevx');//from news and events
            $tnev = $request->getGet('tnev');//to news and events


            if (isset($user) && !empty($user)) {
                $filters['users.u_id'] = $user;
            }
            if (isset($fud) && !empty($fud)) {
                $filters['users.u_date  >='] = $fud;
            }
            if (isset($tud) && !empty($tud)) {
                $filters['users.u_date <='] = $tud;
            }

            if (isset($fnevx) && !empty($fnevx)) {
                $filters['newsevents.ne_date  >='] = $fnevx;
            }
            if (isset($tnev) && !empty($tnev)) {
                $filters['newsevents.ne_date <='] = $tnev;
            }


        }
        return $filters;
    }
    /*private methods here*/





    /*club code ends here*/

    public function newadmin()
    {
        if (isAdmin() && isSuperAdmin()){
            $tableUsers = new ModUsers();
            $data['AllUsers'] = $tableUsers->where('u_status',1)->findAll();
            $data['title'] =  'New Admin | ' .PROJECT;
           echo view('admin/header/header',$data);
           echo view('admin/css/css');
            //echo view('admin/css/datePicker');
           echo view('css/bootstrapSelect');
           echo view('css/formValidation');
           echo view('admin/navbar/navbartop');
           echo view('admin/navbar/navbar_left');
           echo view('admin/content/newadmin',$data);
           echo view('admin/footer/footer');
           echo view('js/formValidation');
           echo view('admin/js/newadmin');
            //echo view('admin/js/datePicker');
           echo view('js/bootstrapSelect');
           echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }
    }

    public function addadmin()
    {
        if (isAdmin() && isSuperAdmin()) {
            $validation = $this->validator;
            $request = $this->request;
            if (!$this->validate($validation->getRuleGroup('newAdmin')))
            {
                $this->newadmin();
            }
            else {
                $data['aName'] = $request->getPost('name');//$this->input->post('name', TRUE);
                $data['email'] = $request->getPost('email');//$this->input->post('email', TRUE);
                $data['password'] = $request->getPost('password');//$this->input->post('password', TRUE);
                $data['aStatus'] = $request->getPost('status');//$this->input->post('status', TRUE);
                $data['aSuperAdmin'] = 0;
                $tableAdmin = new ModAdmin();
                $data['aDate'] = date('Y-m-d H:i:s');
                //$data['admin_id'] = getAdminId();
                $isAdmin = $tableAdmin->where(['email'=>$data['email']])->findAll();
                //$isAdmin = $this->modAdmin->chackAdmin($data);
                if (count($isAdmin) > 0){
                    if ($isAdmin[0]['aStatus'] == 0){
                        customFlash('alert-warning','This email <strong> ' . $isAdmin[0]['email'] . ' </strong> already registered but its not activated.');
                        return redirect()->to(site_url('admin/newadmin'));
                    }
                    else{
                        //echo $user[0]['uStatus'];
                        customFlash('alert-warning','This email <strong> ' . $isAdmin[0]['email'] . ' </strong> address is already available.');
                        return redirect()->to(site_url('admin/newadmin'));
                    }
                }
                else{
                    $data['password'] = hash('md5',$data['password']);
                    //$data['u_link'] = random_string('alnum', 20);
                    //echo $data['u_ref_id'] = '5stark'.random_string('numeric', 7).date('s'); ;//random_string('alnum', 5).date('m').date('d').date('His');
                    //die();
                    //$newAdmin = $this->modAdmin->addNewAdmin($data);//userId
                    $newAdmin = $tableAdmin->insert($data);//userId
                    if ($newAdmin){
                        customFlash('alert-success','You have successfully created the admin.');
                        return redirect()->to(site_url('admin/newadmin'));
                    }
                    else{
                        customFlash('alert-warning','We can\'t register you right now please try again.');
                        return redirect()->to(site_url('admin/newadmin'));
                    }

                }

            }
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }


    public function all()
    {
        if (isAdmin() && isSuperAdmin()){
            $request = $this->request;
            $tableAdmin = new ModAdmin();
            $tableAdmin->fatchAdmins();
            $data = [
                'allAdmins' => $tableAdmin->paginate(20),
                'pager' => $tableAdmin->pager
            ];


            $data['title'] =  'All Admins | ' .PROJECT;
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/all',$data);
            echo view('admin/footer/footer');
            //echo view('admin/footer/homeJs');
            echo view('admin/endfooter/endfooter');


        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }

    public function editadmin($id)
    {
        if (isAdmin() && isSuperAdmin()){
            if (!empty($id) && isset($id)) {
                $tableAdmin = new ModAdmin();
                $isAdmin = $tableAdmin->where(['aId'=>$id])->findAll();
                //$isAdmin = $this->modAdmin->checkAdminById($id);
                if (count($isAdmin) === 1) {
                    $data['admins'] = $isAdmin  ;
                    $data['title'] =  'New Admin | ' .PROJECT;
                    echo view('admin/header/header',$data);
                    echo view('admin/css/css');
                    //echo view('admin/css/datePicker');
                    echo view('css/bootstrapSelect');
                    echo view('css/formValidation');
                    echo view('admin/navbar/navbartop');
                    echo view('admin/navbar/navbar_left');
                    echo view('admin/content/editadmin',$data);
                    echo view('admin/footer/footer');
                    echo view('js/formValidation');
                    echo view('admin/js/editadmin');
                    //echo view('admin/js/datePicker');
                    echo view('js/bootstrapSelect');
                    echo view('admin/endfooter/endfooter');
                }
                else{
                    customFlash('alert-warning','The Plan is not available please try again.');
                    return redirect()->to(site_url('admin/all'));
                }
            }
            else{
                customFlash('alert-warning','Some thing went wrong.');
                return redirect()->to(site_url('admin/all'));
            }
        }
        else{
            customFlash('alert-warning','Please login first.');
            return redirect()->to(site_url('admin/login'));
        }

    }

    public function updateadmin()
    {
        if (isAdmin() && isSuperAdmin()){
            $validation = $this->validator;
            $request = $this->request;
            //$this->form_validation->set_rules('xeew', 'Admin Id', 'trim|required|integer');
            $adminAdd = $validation->getRuleGroup('newAdmin');
            $adminAdd['xeew'] = 'trim|required|integer';
            //var_dump($adminAdd);
            //dd();
            if (!$this->validate($adminAdd))
            {
                customFlash('alert-danger','Please check the required fields and try again');
                return redirect()->to(site_url('admin/all'));
            }
            else
            {
                $tableAdmin = new ModAdmin();
                $AdminId = $request->getPost('xeew');//$this->input->post('xeew',TRUE);
                $data['aName'] = $request->getPost('name');//$this->input->post('name', TRUE);
                $data['email'] = $request->getPost('email');//$this->input->post('email', TRUE);
                $data['password'] = $request->getPost('password');//$this->input->post('password', TRUE);
                $data['aStatus'] = $request->getPost('status');//$this->input->post('status', TRUE);
                $data['aSuperAdmin'] = 0;

                $data['aUpdateDate'] =  date('Y-m-d h:i:sa');
                if (!empty($AdminId) && isset($AdminId)) {
                    $myWhere = array(
                        'email'=>$data['email'],
                        'aId !='=>$AdminId,
                    );
                    $checkAdmin = $tableAdmin->where($myWhere)->findAll();
                    //$checkPlan = $this->modAdmin->chackAdmin($data,$AdminId);
                    if (count($checkAdmin) > 0) {
                        customFlash('alert-danger','Admin already exist.');
                        return redirect()->to(site_url('admin/editadmin/'.$AdminId));
                    }
                    else{
                        $data['password'] = hash('md5',$data['password']);
                        $isUpdated = $tableAdmin->update($AdminId,$data);
                        //$story = $this->modAdmin->updateAdmin($data,$AdminId);
                        if ($isUpdated) {
                            customFlash('alert-success','You have successfully updated your plan');
                            return redirect()->to(site_url('admin/all'));
                        }
                        else{
                            customFlash('alert-danger','OOps..! something went wrong please try again.');
                            return redirect()->to(site_url('admin/all'));
                        }
                    }

                }
                else{
                    customFlash('alert-danger','Something went wrong please try again');
                    return redirect()->to(site_url('admin/all'));
                }

            }
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }
    }


    public function newcashbox()
    {
        if (isAdmin() && isSuperAdmin()){
            $tableUsers = new ModUsers();
            $data['AllUsers'] = $tableUsers->where(['u_status',1])->findAll();
            $data['title'] =  'All Messages | ' .PROJECT;
            echo view('admin/header/header',$data);
            echo view('admin/css/css');
            echo view('admin/css/datePicker');
            echo view('css/bootstrapSelect');
            echo view('css/formValidation');
            echo view('admin/navbar/navbartop');
            echo view('admin/navbar/navbar_left');
            echo view('admin/content/newcashbox',$data);
            echo view('admin/footer/footer');
            echo view('js/formValidation');
            echo view('admin/js/newcashbox');
            echo view('admin/js/datePicker');
            echo view('js/bootstrapSelect');
            echo view('admin/endfooter/endfooter');
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }
    public function addcashbox()
    {
        if (isAdmin() && isSuperAdmin()) {
           /* $this->form_validation->set_rules('userId', 'User ID', 'trim|required|integer');
            $this->form_validation->set_rules('mydate', 'Date', 'trim|required');
            $this->form_validation->set_rules('currency', 'Currency', 'trim|required');
            $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');
            //$this->form_validation->set_rules('bank_transaction', 'Maximum Amount', 'trim|required|integer');
            $this->form_validation->set_rules('status', 'Status', 'trim|required|integer');*/
            $validation = $this->validator;
            $request = $this->request;
            if (!$this->validate($validation->getRuleGroup('newCashBox')))
            {
                $this->newcashbox();
            }
            else {
                $data['user_id'] = $request->getPost('userId');//$this->input->post('userId', TRUE);
                $data['cb_date'] = $request->getPost('mydate');//$this->input->post('mydate', TRUE);
                $data['cb_currency'] = $request->getPost('currency');//$this->input->post('currency', TRUE);
                $data['cb_amount'] = $request->getPost('amount');//$this->input->post('amount', TRUE);
                $data['cb_bank_transaction_id'] = $request->getPost('bank_transaction');//$this->input->post('bank_transaction', TRUE);
                $data['cb_status'] = $request->getPost('status');//$this->input->post('status', TRUE);

                $data['cb_inserted_date'] = date('Y-m-d H:i:s');
                $data['admin_id'] = getAdminId();
                $data['cb_type'] = 'Sent By Admin';
                $tableUserCashBox = new ModUserCashBox();
                $UserCashBox = $tableUserCashBox->insert($data);
                //$UserCashBox = $this->modAdmin->addUserCashBox($data);
                if ($UserCashBox) {
                    customFlash('alert-success','You have successfully inserted');
                    return redirect()->to(site_url('admin/newcashbox'));
                }
                else{
                    customFlash('alert-danger','OOps..! something went wrong please try again.');
                    return redirect()->to(site_url('admin/newcashbox'));
                }
                //$checkAboutUs = $this->modAdmin->checkUserCashBox($data);
                /*if ($checkAboutUs->num_rows() > 0) {
                    customFlash('alert-danger', $data['pl_name']. ' plan already exist.','admin/new-tender');
                }
                else{

                }*/
            }
        }
        else{
            customFlash('alert-danger','Please login first to access the admin panel');
            return redirect()->to(site_url('admin/login'));
        }

    }







}//class here
