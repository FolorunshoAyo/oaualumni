<?php


namespace App\Controllers;

use App\Models\ModContact;

class Pages extends BaseController
{
    function __construct()
    {
        $this->validator = \Config\Services::validation();
        $this->request = \Config\Services::request();
        $this->session = \Config\Services::session();
    }


    protected $helpers = ['url', 'custom_helper','form','text'];

    public function testing()
    {
         $cashboxDate = getCashBoxAfterDate(getUserId());
         $withDrawDate =getWithdrawlAfterDate(getUserId());
         echo $cashboxDate.'Cashbox';
         echo '<br><br><br>';
        echo $withDrawDate.'Withdraw';

    }
    public function about()
    {
      $data['title'] = 'About' . PROJECT;
      $data['description'] = 'About page description';
       echo view('header/header',$data);
       echo view('css/allCSS');
       echo view('css/whatsapp');
       echo view('header/navbar');
       echo view('content/about',$data);
       echo view('footer/footer');
       echo view('js/whatsapp');
       echo view('footer/endfooter');
    }



    public function faq()
    {
        $data['title'] = 'FAQ' . PROJECT;
        //$data['description'] = 'FAQ';
        echo view('header/header',$data);
        echo view('css/allCSS');
        echo view('css/phone');
        echo view('header/navbar');
        echo view('users/faq',$data);
        echo view('content/subscribed');
        echo view('footer/footer');
        echo view('js/phone');
        echo view('footer/endfooter');
    }

    public function terms()
    {
        $data['title'] = 'Terms' . PROJECT;
        //$data['description'] = 'FAQ';
        echo view('header/header',$data);
        echo view('css/allCSS');
        echo view('css/phone');
        echo view('header/navbar');
        echo view('users/terms',$data);
        echo view('content/subscribed');
        echo view('footer/footer');
        echo view('js/phone');
        echo view('footer/endfooter');
    }



    public function contact()
    {
        $data['title'] = 'Contact' . PROJECT;
        $data['description'] = 'Contact';
        echo view('header/header',$data);
        echo view('css/allCSS');
        echo view('css/phone');
        echo view('header/navbar');
        echo view('users/contact',$data);
        echo view('content/subscribed');
        echo view('footer/footer');
        echo view('js/phone');
        echo view('footer/endfooter');

    }

    public function userQuery()
    {

        $validation = $this->validator;
        $request = $this->request;
        $session =  $this->session;
        customFlash('alert-warning','Please check your required fields and try again','contact');
        //dd();
        if (!$this->validate($validation->getRuleGroup('userQuery'))){
            customFlash('alert-warning','Please check your required fields and try again','contact');
            return redirect()->to(site_url('contact'));

        }
        else{
            $myUser = [
                'u_email'=>$request->getPost('email'),
            ];

            $ModCotnact = new ModContact();
            if (isUserLoggedIn()) {
                $newContact = [
                    'user_id'=>session('u_id'),
                    'con_message'=>$request->getPost('message'),
                ];
            }

            $newContact = [
                'con_name'=>$request->getPost('name'),
                'con_email'=>$request->getPost('email'),
                'con_phone'=>$request->getPost('relPhone'),
                'con_message'=>$request->getPost('message'),
                'con_subject'=>$request->getPost('subject'),
            ];
            $ifQueryInserted = $ModCotnact->insert($newContact);

            if ($ifQueryInserted){
                /*if (getUserAgent()) {
                    $message =  view('emails/contactForm',$newContact);
                    $email = \Config\Services::email();
                    $email->setFrom(EMAIL, '5Stark');
                    $email->setTo('shakzee171@gmail.com');
                    $email->setSubject('New Message | 5stark.com');
                    $email->setMessage($message);//your message here
                    $email->send();

                }*/
                customFlash('alert-success','Thanks for being in touch with us. Over the next 24 hours, our representative will email you.','contact');
                return redirect()->to(site_url('contact'));
            }
            else{
                customFlash('alert-warning','Something went wrong, please try again.','contact');
                return redirect()->to(site_url('contact'));

            }

        }
    }
    public function newdevice($link)
    {
        $data['title'] = 'Contact' . PROJECT;
        $data['description'] = 'Contact';
        echo view('header/header',$data);
        echo view('css/allCSS');
        echo view('css/phone');
        echo view('css/formValidation');
        echo view('header/navbar');
        echo view('content/contact',$data);
        echo view('footer/footer');
        echo view('js/phone');
        echo view('js/formValidation');
        echo view('footer/endfooter');

    }

}//class hre