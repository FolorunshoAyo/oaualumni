<?php

namespace App\Controllers;

use App\Models\ModNewEvents;

class Home extends BaseController
{
    protected $helpers = ['url', 'file', 'custom_helper','form','filesystem','text'];
    public function index()
    {
        $tablePClip = new ModNewEvents();
        $data['title'] = 'Home' . PROJECT;
        $data['description'] = 'Home';
        $data['newshome']= $tablePClip->where('ne_category','news')->findAll(2);
        echo view('header/header',$data);
        echo view('css/allCSS');
        echo view('css/owl');
        echo view('header/homenavbar');
        echo view('header/Homebanner');
        echo view('content/MainHome',$data);
        echo view('content/subscribed');
        echo view('footer/footer');
        echo view('footer/endfooter');
    }


}//class here
