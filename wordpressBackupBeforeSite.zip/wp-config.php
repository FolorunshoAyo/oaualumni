<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u595490171_under_const' );

/** MySQL database username */
define( 'DB_USER', 'u595490171_under_const' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Under_const123$' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '?RN>j`!0*:Ok}1&i-K^#nOGUyeX9DeHLIy!8dRS;p@E%;|9MU]%2+&~t>,e J,gz' );
define( 'SECURE_AUTH_KEY',  ',NiI|5-|YL0f_h&zI`.cMWXl7A)OdNX>|zy:3k[g7k::Y+C&Sir;Ttto%b|*4NR}' );
define( 'LOGGED_IN_KEY',    '?)]7J[.I_Rr;avF[?B<bl?7!G9g@2fMNFV4:W@`*[K|H{&;iJ63Yn&8G}fqP=j$4' );
define( 'NONCE_KEY',        '<c{9]4JWKR7PF#RYBLyJrd,0~J5mWDvoOZ)2#x^&aEF#`;0j/qrbWNXx!F0;5ybB' );
define( 'AUTH_SALT',        'iu,(9(=<7nj@XQ&GKVzT_hjt4qubWMJa&Ws)xV[pY?kUZMf5 e+g[# k, z&?sW ' );
define( 'SECURE_AUTH_SALT', 'y_&Q)t24*61wdO7xXn&DOpv/%xP)HjM.iEN[T&Fm8N8)|XOZCEh2>L2@rEXu{BYJ' );
define( 'LOGGED_IN_SALT',   '@_P|(fKf&8LW([Wt3:uo10s cO@~H~Gdb2rU4!5M09#h?OY5?+2?Y=5h.l#C!2%:' );
define( 'NONCE_SALT',       'SuS#1v*{,0wv~w~(uMv ZLS@`g3qKJ**_imO5sF5apK<,&yOim!8l2ZPte:X!S{0' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
