<!--============== Subscribe Section Start ==============-->
<div class="full-row bg-gray p-0">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="divider py-80">
                    <div class="row align-items-center g-3">
                        <div class="col-lg-7">
                            <h4 class="text-secondary mb-0">Enter your email for subscribe to get monthly newslatter</h4>
                        </div>
                        <div class="col-lg-5">
                                <div class="input-group start_partner tac-smd">
                                    <input type="email" id="sbtxet" class="form-control" placeholder="Enter your email">
                                    <button class="btn btn-primary skzsbt" type="submit">Subscribe</button>
                                </div>
                        </div>
                        <div class="row margb20">
                            <div class="col-lg-8 offset-2">
                                <div class="subfdbk"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--============== Subscribe Section End ==============-->