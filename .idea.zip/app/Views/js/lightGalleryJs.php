

<script type="text/javascript">
    $(document).ready(function(){
        $('.xkksi').lightGallery();
    });
</script>
<script src="https://cdn.jsdelivr.net/picturefill/2.3.1/picturefill.min.js"></script>
<script src="<?php echo base_url('public/assets/light/dist/js/lightgallery-all.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/light/lib/jquery.mousewheel.min.js')?>"></script>
