

<link href="<?php echo base_url('assets/css/plugins/responsive-table/css/rwd-table.min.css')?>" rel="stylesheet" type="text/css" media="screen">
<!--<p>../plugins/responsive-table/css/rwd-table.min.css</p>-->
