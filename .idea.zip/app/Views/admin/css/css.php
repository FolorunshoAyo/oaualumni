<?php
/**
 * Created by PhpStorm.
 * User: mymac
 * Date: 13/10/2017
 * Time: 11:51 AM
 */
?>
<!-- ========== Css Files ========== -->
<link href="<?php echo base_url('public/assets/admin/css/root.css')?>" rel="stylesheet">
<link href="<?php echo base_url('public/assets/admin/css/custom.css?version='.CSSJSVERSION)?>" rel="stylesheet">
<link href="<?php echo base_url('public/assets/css/adminStyle.css?version='.CSSJSVERSION)?>" type="text/css" rel="stylesheet" />