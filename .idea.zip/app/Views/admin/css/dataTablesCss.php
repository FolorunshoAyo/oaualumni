
<!-- DataTables -->
<link href="<?php echo base_url('assets/css/plugins/datatables/dataTables.bootstrap4.min.css')?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('assets/css/plugins/datatables/buttons.bootstrap4.min.css')?>" rel="stylesheet" type="text/css" />

