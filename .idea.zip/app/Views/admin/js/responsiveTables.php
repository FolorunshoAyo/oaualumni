

<!-- responsive-table-->
<script src="<?php echo base_url('assets/css/plugins/responsive-table/js/rwd-table.min.js')?>" type="text/javascript"></script>

