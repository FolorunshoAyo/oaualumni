

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo base_url('public/assets/images/'.getwebsiteSetting('st_fav_icon'))?>">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Muli:400,400i,500,600,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Comfortaa:400,700" rel="stylesheet">

<!-- Css Link -->
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/bootstrap-slider.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/all.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/jquery-ui.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/layerslider.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/color.css')?>" id="color-change">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/css/owl.carousel.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('public/assets/club/webfonts/flaticon/flaticon.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/assets/club/css/style.css?version='.CSSJSVERSION)?>">