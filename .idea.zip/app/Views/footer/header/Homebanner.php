<!--============== Slider HTML markup Section Start ==============-->
<div class="full-row overflow-hidden p-0">
    <div id="image-slider-2" style="width:1200px; height:800px;">

        <!-- Slide 1-->
        <div class="ls-slide" data-ls="bgposition:50% 50%; duration:9000; transition2d:4; kenburnsscale:1.2;"> <img width="1920" height="1080" src="<?php echo base_url('public/assets/club/images/slider/01.jpg')?>" class="ls-bg" alt="" />
            <div style="top:50%; left:50%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; width:100%; height:100%;" class="ls-l slider-layer-1" data-ls="showinfo:1; position:fixed; durationout:400;"></div>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:76px; color:#ffffff; top:320px; left:50px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:300; offsetyout:-30; durationout:400; parallaxlevel:0;">Why do we use it?</p>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:20px; top:290px; left:50px;" class="ls-l text-primary" data-ls="offsetyin:30; durationin:1000; delayin:150 offsetyout:-30; durationout:400; parallaxlevel:0;">Dream</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:370px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:600; offsetyout:-30; durationout:400; parallaxlevel:0;">
                Why do we use it?
            </p>
            <div style="top:440px; left:53px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; height:2px; width:350px; background:#adadad;" class="ls-l" data-ls="showinfo:1; durationin:1000; delayin:1200; offsetyout:-30; durationout:400; scalexin:0;"></div>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:430px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:1600; offsetyout:-30; durationout:400; parallaxlevel:0;"><i class="fas fa-map-marker-alt text-primary"></i> 1744 Daylene Drive Newport MI 48166, Australia</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:470px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:0; durationin:1000; delayin:2200; offsetyout:-30; durationout:400; parallaxlevel:0;">$ 12500.00 / Monthly</p>
            <a class="ls-l" href="#" target="-self" data-ls="offsetyin:30; durationin:1000; delayin:2800; offsetyout:-30; durationout:400; hover:true; hoverdurationin:300; hoveropacity:1; hoverbgcolor:#ffffff; hovercolor:#444444; parallaxlevel:0;">
                <p style="font-weight:500; text-align:center;cursor:pointer; padding-top:8px; padding-bottom:7px; font-family:'Varela Round', sans-serif; font-size:15px; top:560px; left:53px; border-top:2px solid #fff; border-right:2px solid #fff; padding-right:25px; border-bottom:2px solid #fff; border-left:2px solid #fff; padding-left:25px; line-height:30px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; color:#ffffff; background:rgba(0, 0, 0, 0.1); border-radius:2px; font-weight:500; text-align:center; cursor:pointer;"
                   class="ls-button">View Details</p>
            </a>
            <div style="text-align:center; width:100px; height:35px; line-height: 35px; font-family:'Varela Round', sans-serif; font-size:15px; color:#ffffff; border-radius:3px; top:490px; left:260px;" class="ls-l bg-primary" data-ls="delayin:3200; easingin:easeOutElastic; rotateyin:-300; durationout:400; rotateyout:-400; parallaxlevel:0;">For Rent</div>
        </div>

        <!-- Slide 2-->
        <div class="ls-slide" data-ls="bgposition:50% 50%; duration:9000; transition2d:4; kenburnsscale:1.2;"> <img width="1920" height="1080" src="<?php echo base_url('public/assets/club/images/slider/01.jpg')?>" class="ls-bg" alt="" />
            <div style="top:50%; left:50%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; width:100%; height:100%;" class="ls-l slider-layer-1" data-ls="showinfo:1; position:fixed; durationout:400;"></div>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:76px; color:#ffffff; top:320px; left:50px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:300; offsetyout:-30; durationout:400; parallaxlevel:0;">Why do we use it?</p>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:20px; top:290px; left:50px;" class="ls-l text-primary" data-ls="offsetyin:30; durationin:1000; delayin:150 offsetyout:-30; durationout:400; parallaxlevel:0;">Dream</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:370px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:600; offsetyout:-30; durationout:400; parallaxlevel:0;">
                Why do we use it?</p>
            <div style="top:440px; left:53px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; height:2px; width:350px; background:#adadad;" class="ls-l" data-ls="showinfo:1; durationin:1000; delayin:1200; offsetyout:-30; durationout:400; scalexin:0;"></div>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:430px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:1600; offsetyout:-30; durationout:400; parallaxlevel:0;"><i class="fas fa-map-marker-alt text-primary"></i> 1744 Daylene Drive Newport MI 48166, Australia</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:470px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:0; durationin:1000; delayin:2200; offsetyout:-30; durationout:400; parallaxlevel:0;">$ 12500.00 / Monthly</p>
            <a class="ls-l" href="#" target="-self" data-ls="offsetyin:30; durationin:1000; delayin:2800; offsetyout:-30; durationout:400; hover:true; hoverdurationin:300; hoveropacity:1; hoverbgcolor:#ffffff; hovercolor:#444444; parallaxlevel:0;">
                <p style="font-weight:500; text-align:center;cursor:pointer; padding-top:8px; padding-bottom:7px; font-family:'Varela Round', sans-serif; font-size:15px; top:560px; left:53px; border-top:2px solid #fff; border-right:2px solid #fff; padding-right:25px; border-bottom:2px solid #fff; border-left:2px solid #fff; padding-left:25px; line-height:30px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; color:#ffffff; background:rgba(0, 0, 0, 0.1); border-radius:2px; font-weight:500; text-align:center;cursor:pointer;"
                   class="ls-button">View Details</p>
            </a>
            <div style="text-align:center; width:100px; height:35px; line-height: 35px; font-family:'Varela Round', sans-serif; font-size:15px; color:#ffffff; border-radius:3px; top:490px; left:260px;" class="ls-l bg-primary" data-ls="delayin:3200; easingin:easeOutElastic; rotateyin:-300; durationout:400; rotateyout:-400; parallaxlevel:0;">For Rent</div>
        </div>

        <!-- Slide 3-->
        <div class="ls-slide" data-ls="bgposition:50% 50%; duration:9000; transition2d:4; kenburnsscale:1.2;"> <img width="1920" height="1080" src="<?php echo base_url('public/assets/club/images/slider/01.jpg')?>" class="ls-bg" alt="" />
            <div style="top:50%; left:50%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; width:100%; height:100%;" class="ls-l slider-layer-1" data-ls="showinfo:1; position:fixed; durationout:400;"></div>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:76px; color:#ffffff; top:320px; left:50px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:300; offsetyout:-30; durationout:400; parallaxlevel:0;">Why do we use it?</p>
            <p style="font-weight:600; font-family:'Comfortaa', cursive; font-size:2.5rem; line-height:20px; top:290px; left:50px;" class="ls-l text-primary" data-ls="offsetyin:30; durationin:1000; delayin:150 offsetyout:-30; durationout:400; parallaxlevel:0;">Dream</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:370px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:600; offsetyout:-30; durationout:400; parallaxlevel:0;">
                Why do we use it?h</p>
            <div style="top:440px; left:53px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; height:2px; width:350px; background:#adadad;" class="ls-l" data-ls="showinfo:1; durationin:1000; delayin:1200; offsetyout:-30; durationout:400; scalexin:0;"></div>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:430px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:30; durationin:1000; delayin:1600; offsetyout:-30; durationout:400; parallaxlevel:0;"><i class="fas fa-map-marker-alt text-primary"></i> 1744 Daylene Drive Newport MI 48166, Australia</p>
            <p style="font-weight:400; font-size:15px; line-height:76px; color:#ffffff; top:470px; left:53px; white-space:nowrap;" class="ls-l" data-ls="offsetyin:0; durationin:1000; delayin:2200; offsetyout:-30; durationout:400; parallaxlevel:0;">$ 12500.00 / Monthly</p>
            <a class="ls-l" href="#" target="-self" data-ls="offsetyin:30; durationin:1000; delayin:2800; offsetyout:-30; durationout:400; hover:true; hoverdurationin:300; hoveropacity:1; hoverbgcolor:#ffffff; hovercolor:#444444; parallaxlevel:0;">
                <p style="font-weight:500; text-align:center;cursor:pointer; padding-top:8px; padding-bottom:7px; font-family:'Varela Round', sans-serif; font-size:15px; top:560px; left:53px; border-top:2px solid #fff; border-right:2px solid #fff; padding-right:25px; border-bottom:2px solid #fff; border-left:2px solid #fff; padding-left:25px; line-height:30px; text-align:initial; font-weight:400; font-style:normal; text-decoration:none; color:#ffffff; background:rgba(0, 0, 0, 0.1); border-radius:2px; font-weight:500; text-align:center;cursor:pointer;"
                   class="ls-button">View Details</p>
            </a>
            <div style="text-align:center; width:100px; height:35px; line-height: 35px; font-family:'Varela Round', sans-serif; font-size:15px; color:#ffffff; border-radius:3px; top:490px; left:260px;" class="ls-l bg-primary" data-ls="delayin:3200; easingin:easeOutElastic; rotateyin:-300; durationout:400; rotateyout:-400; parallaxlevel:0;">For Rent</div>
        </div>
    </div>
</div>
<!--============== Slider HTML markup Section End ==============-->