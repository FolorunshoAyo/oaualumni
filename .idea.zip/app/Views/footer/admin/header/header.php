<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>
        <?php
        if (isset($title)){
            echo $title;
        }
        else{
            echo '5stark';
        }
        ?>
    </title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
	<meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />

    <!-- App favicon -->
    <link rel="shortcut icon" type="image/png" href="<?php echo base_url('public/assets/images/Fav-icon.png')?>"/>
<!--    <link rel="shortcut icon" href="assets/images/favicon.ico">-->




