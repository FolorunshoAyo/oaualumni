<?php
/**
 * Created by PhpStorm.
 * User: mymac
 * Date: 13/10/2017
 * Time: 11:51 AM
 */
?>
<!-- ========== Css Files ========== -->
<link href="<?php echo base_url('public/assets/admin/css/root.css')?>" rel="stylesheet">
<link href="<?php echo base_url('public/assets/admin/css/custom.css?version=313')?>" rel="stylesheet">
<link href="<?php echo base_url('public/assets/css/adminStyle.css')?>" type="text/css" rel="stylesheet" />