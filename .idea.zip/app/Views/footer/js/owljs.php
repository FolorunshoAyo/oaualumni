<script src="<?php echo base_url('public/assets/club/js/owlscript.js')?>"></script>
