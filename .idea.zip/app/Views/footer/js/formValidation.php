
<script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('public/assets/forms/dist/js/FormValidation.full.min.js')?>"></script>
<script src="<?php echo base_url('public/assets/forms/dist/js/plugins/Bootstrap.min.js')?>"></script>
<!--<script src="<?php /*echo base_url('assets/js/bootstrap.min.js')*/?>"  type="text/javascript"></script>-->
