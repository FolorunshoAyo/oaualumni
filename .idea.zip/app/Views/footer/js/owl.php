
<script src="<?php echo base_url('public/assets/club/js/owl.carousel.min.js')?>"></script>
