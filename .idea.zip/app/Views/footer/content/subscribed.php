<!--============== Subscribe Section Start ==============-->
<div class="full-row bg-gray p-0">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="divider py-80">
                    <div class="row align-items-center g-3">
                        <div class="col-lg-7">
                            <h4 class="text-secondary mb-0">Enter your email for subscribe to get monthly newslatter</h4>
                        </div>
                        <div class="col-lg-5">
                            <form class="subscribe">
                                <div class="input-group">
                                    <input type="email" class="form-control" placeholder="Enter your email">
                                    <button class="btn btn-primary" type="submit">Subscribe</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--============== Subscribe Section End ==============-->